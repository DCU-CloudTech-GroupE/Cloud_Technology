import tweepy
import json

ctoken = "xxxxxxxxxx"
csecret = "xxxxxxxxxx"
key = "xxxxxxxxxx"
secret = "xxxxxxxxxx"


auth = tweepy.OAuthHandler(ctoken, csecret)
auth.set_access_token(key, secret)


# new api connection
api = tweepy.API(auth
                 , retry_count=3
                 , retry_delay=5
                 , retry_errors=set([401, 404, 500, 503])
                 , wait_on_rate_limit_notify=True
                 , wait_on_rate_limit=True
                )

#tweet searh paramter
max_tweets = 10
query = 'Trump'
language = 'en'
sincedt = '2018-03-10'

searched_tweets = ([status._json for status in tweepy.Cursor(api.search,
                                                               q=query, 
                                                               since=sincedt,
                                                               lang=language
                                                               ).items(max_tweets)])

#twitterDataFile.write(simplejson.dumps(simplejson.loads(output), indent=4, sort_keys=True))
#twitterDataFile.close()
with open('TrumpRawTest.json', 'w', encoding="utf-8") as f:
    json.dump(searched_tweets, f, ensure_ascii=False, indent=4, sort_keys=True)
