import ijson
import pandas   as pd
import numpy    as np
import csv
import time
import os
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

senti = SentimentIntensityAnalyzer()

query = 'TrumpTest'
filepath = r'/home/ubuntu/TrumpRawTest.json'
filename = 'TrumpRawTest.json'
# Using ijson library extracting selected fileds from raw trump json file
with open(filepath, 'rb' ) as f:
     id_str = pd.DataFrame(data=(list(ijson.items(f, 'item.id_str'))) , columns = ['id_str'])
     # prefixing the id string with 'id' as excel has an issue with handling big integers
     id_str = 'id'+id_str
    
with open(filepath, 'rb' ) as f:
    created_at = pd.DataFrame(data=(list(ijson.items(f, 'item.created_at'))) , columns = ['created_at'])

with open(filepath, 'rb' ) as f:
    retweet_count = pd.DataFrame(data=(list(ijson.items(f, 'item.retweet_count'))) , columns = ['retweet_count'])

with open(filepath, 'rb' ) as f:
    retweet_count = pd.DataFrame(data=(list(ijson.items(f, 'item.retweet_count'))) , columns = ['retweet_count'])    

with open(filepath, 'rb' ) as f:
    followers_count = pd.DataFrame(data=(list(ijson.items(f, 'item.user.followers_count'))) , columns = ['followers_count'])    

with open(filepath, 'rb' ) as f:
    followers_count = pd.DataFrame(data=(list(ijson.items(f, 'item.user.followers_count'))) , columns = ['followers_count'])
    
with open(filepath, 'rb' ) as f:
    text = pd.DataFrame(data=(list(ijson.items(f, 'item.text'))) , columns = ['text'])
     # remove new line character from all columns
    text = text.replace('\\n',' ', regex=True)
    text = text.replace('\n',' ', regex=True)
    text = text.replace('\r', ' ', regex=True)
    text = text.replace('\\r', ' ', regex=True)
    

# Build a Dataframe by concatenating extracted fields
tweet_data = pd.concat([id_str, created_at, text, followers_count, retweet_count],axis=1)

# Reformat and an extract date and time stamp element from create_at column
tweet_date = []
tweet_time = []
tweet_tmstmp =[]
for tmstmp in tweet_data['created_at']:
    ts = time.strftime('%Y-%m-%d %H:%M:%S', time.strptime(str(tmstmp),'%a %b %d %H:%M:%S +0000 %Y'))
    dte = time.strftime('%Y-%m-%d', time.strptime(str(tmstmp),'%a %b %d %H:%M:%S +0000 %Y'))
    tme = time.strftime('%H:%M:%S', time.strptime(str(tmstmp),'%a %b %d %H:%M:%S +0000 %Y'))   
    tweet_tmstmp.append(ts)
    tweet_date.append(dte)
    tweet_time.append(tme)
    
tweet_data['tweet tmstmp'] = tweet_tmstmp
tweet_data['tweet date'] = tweet_date
tweet_data['tweet time'] = tweet_time
    
# Adding Sentiment Analysis scores to tweet_data DataFrame
compound=[]
neg=[]
pos=[]
neu=[]
for tweet in tweet_data['text']:
    snt = senti.polarity_scores(tweet)
    compound.append(str(snt['compound']))
    neg.append(str(snt['neg']))
    pos.append(str(snt['pos']))
    neu.append(str(snt['neu']))
    
tweet_data['negative score'] = neg
tweet_data['neutral score'] = neu
tweet_data['positive score'] = pos
tweet_data['compound score'] = compound


# output tweet data to a .csv file
tweet_data.to_csv('%s.csv'% query, encoding='utf-8')
#print(tweet_data)

# Move file from EC2 to S3 client
import boto3

# Create an S3 client
s3 = boto3.client('s3',
    aws_access_key_id="xxxxxxx",
    aws_secret_access_key="xxxxxxx") 
CSVfilename = "%s.csv" % query
bucket_name = 'twitteroutput'

# Uploads the file using a managed uploader, which will split up large
# files automatically and upload parts in parallel.
s3.upload_file(CSVfilename, bucket_name, CSVfilename)
s3.upload_file(filename, bucket_name, filename)

# remove files from EC2 instance
try:
    os.remove(filename)
except OSError:
    pass

try:
    os.remove(CSVfilename)
except OSError:
    pass
