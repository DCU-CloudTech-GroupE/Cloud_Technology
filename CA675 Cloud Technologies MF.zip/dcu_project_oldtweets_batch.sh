#!/bin/bash

python3 dcu_project_oldtweets_download.py
echo "Download completed"

python3 dcu_project_oldtweets_sentiment.py
echo "Sentiment completed"

python3 dcu_project_oldtweets_wordcount.py
echo "Word Count completed"
