import re
import pandas as pd

query = 'TrumpWordCount'

### Load Sentiment Analysis output from CSV file
text = pd.read_csv(r"/home/ubuntu/Trump100k.csv")
### Calculate the number of rows in the tweets list
total_rows=len(pd.DataFrame(text).index)

### Set Pandaframe to display all characters in the text column
pd.set_option("display.max_colwidth", 10000)
pd.set_option("display.max_rows",total_rows)
text = str(text[["text"]])


## Text Cleaning
### Remove Punctuation
text = re.sub(r'[^\w\s]',' ', text)

### Split Tweet texts into words
string_list = text.lower().split()


string_dict = {}

def word_count(word):
    for word in string_list:
        if word in string_dict:
            string_dict[word] = string_dict[word] + 1
            continue
        else:
            string_dict[word] = 1

    return string_dict

dict = word_count(text)
df = pd.DataFrame.from_dict(dict, orient='index')

df = df.rename_axis('Word').reset_index()\
.assign(length = df.index.str.len()).rename(columns={0:'Count'})

# Remove from the list selected common words
df = df[~df['Word'].isin(['rt', 'i', 'yes','the','t','https','co','a','to','in','is','s','and','of','on','that','for','at'
                          ,'you','this','about','his','are','it','with','has','who','have','as','was','we','be','from'
                          ,'out','if','not','amp','no','just','so','by','but','they','what','how','when','an','up'
                          ,'all','do','like','there','can','will','now','get','d','did','very','us'
                         ,'he','would','because','1','after','doesn','50th','were','our','or'
                          ,'via','your','2','m','where','ve','me','didn','re'
                         ])]
#print(df)
df.to_csv('%s.csv'% query, encoding='utf-8')

# Move file from EC2 to S3 client
import boto3

# Create an S3 client
s3 = boto3.client('s3',
    aws_access_key_id="xxxxxxx",
    aws_secret_access_key="xxxxxxx") 
CSVfilename = "%s.csv" % query
bucket_name = 'twitteroutput'

# Uploads the file using a managed uploader, which will split up large
# files automatically and upload parts in parallel.
s3.upload_file(CSVfilename, bucket_name, CSVfilename)

# remove files from EC2 instance
try:
    os.remove(CSVfilename)
except OSError:
    pass